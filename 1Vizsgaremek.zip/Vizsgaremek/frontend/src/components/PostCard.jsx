import { useState } from 'react'

function PostCard({ post, onLike }) {
  const [isLiked, setIsLiked] = useState(post.isLiked)
  const [likeCount, setLikeCount] = useState(post.likes)

  const handleLike = () => {
    const newLiked = !isLiked
    setIsLiked(newLiked)
    setLikeCount(newLiked ? likeCount + 1 : likeCount - 1)
    onLike(post.id)
  }

  return (
    <div className="post-card">
      <div className="post-image">
        <img 
          src={post.image} 
          alt={post.title}
          loading="lazy"
        />
        <div className="image-overlay">
          <button 
            className={`like-btn ${isLiked ? 'liked' : ''}`}
            onClick={handleLike}
            aria-label="Kedvelés"
          >
            <span className="like-icon">{isLiked ? '♥' : '♡'}</span>
            <span className="like-count">{likeCount}</span>
          </button>
          <button className="comment-btn" aria-label="Hozzászólások">
            <span className="comment-icon">💬</span>
            <span className="comment-count">{post.comments}</span>
          </button>
        </div>
      </div>

      <div className="post-info">
        <h3 className="post-title">{post.title}</h3>
        <p className="post-description">{post.description}</p>
        
        <div className="post-meta">
          <div className="author">
            <img 
              src={post.avatar} 
              alt={post.author}
              className="avatar"
            />
            <span className="author-name">{post.author}</span>
          </div>
          <span className="post-category">{post.category}</span>
        </div>

        <div className="post-tags">
          {post.tags.map(tag => (
            <span key={tag} className="tag">#{tag}</span>
          ))}
        </div>
      </div>
    </div>
  )
}

export default PostCard