function FilterBar({ 
  sortBy, 
  onSortChange, 
  postCount, 
  layoutMode, 
  onLayoutToggle 
}) {
  return (
    <div className="filter-bar">
      <div className="filter-left">
        <span className="post-count">
          {postCount} ALKOTÁS
        </span>
      </div>
      
      <div className="filter-right">
        <div className="sort-options">
          <span className="sort-label">RENDEZÉS:</span>
          <select 
            value={sortBy} 
            onChange={(e) => onSortChange(e.target.value)}
            className="sort-select"
          >
            <option value="newest">Legújabb</option>
            <option value="oldest">Legrégebbi</option>
            <option value="popular">Legnépszerűbb</option>
            <option value="most-comments">Legtöbb hozzászólás</option>
          </select>
        </div>
        
        <button 
          className="layout-btn"
          onClick={onLayoutToggle}
          title="Nézet váltása"
        >
          {layoutMode === 'grid' ? 'MASONRY' : 'RÁCS'}
        </button>
      </div>
    </div>
  )
}

export default FilterBar