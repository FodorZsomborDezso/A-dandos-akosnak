import { useState } from 'react'

function Header({ onSearch, onUploadClick }) {
  const [searchInput, setSearchInput] = useState('')

  const handleSearch = (e) => {
    e.preventDefault()
    onSearch(searchInput)
  }

  return (
    <header className="header">
      <div className="header-container">
        <div className="logo">
          <span className="logo-icon">🎨</span>
          <h1>ArtConnect</h1>
        </div>

        <form className="search-bar" onSubmit={handleSearch}>
          <input
            type="text"
            placeholder="Keresés alkotások, művészek, címkék között..."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
          />
          <button type="submit">
            🔍
          </button>
        </form>

        <div className="header-actions">
          <button 
            className="upload-btn"
            onClick={onUploadClick}
          >
            📤 Feltöltés
          </button>
          <button className="auth-btn">
            👤 Bejelentkezés
          </button>
        </div>
      </div>
    </header>
  )
}

export default Header