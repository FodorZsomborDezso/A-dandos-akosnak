import { useState, useEffect } from 'react'
import Header from '../components/Header'
import PostCard from '../components/PostCard'
import FilterBar from '../components/FilterBar'
import { mockPosts, mockCategories } from '../data'
import '../styles/HomePage.css'

const HomePage = () => {
  const [posts, setPosts] = useState([])
  const [filteredPosts, setFilteredPosts] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [activeCategory, setActiveCategory] = useState('all')
  const [sortBy, setSortBy] = useState('newest')
  const [searchQuery, setSearchQuery] = useState('')
  const [layoutMode, setLayoutMode] = useState('grid')

  useEffect(() => {
    const timer = setTimeout(() => {
      setPosts(mockPosts)
      setFilteredPosts(mockPosts)
      setIsLoading(false)
    }, 500)
    
    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    let result = [...posts]
    
    if (activeCategory !== 'all') {
      const category = mockCategories.find(cat => cat.slug === activeCategory)
      if (category) {
        result = result.filter(post => post.category === category.name)
      }
    }
    
    if (searchQuery.trim() !== '') {
      const query = searchQuery.toLowerCase()
      result = result.filter(post => 
        post.title.toLowerCase().includes(query) ||
        post.description.toLowerCase().includes(query) ||
        post.tags.some(tag => tag.toLowerCase().includes(query)) ||
        post.author.toLowerCase().includes(query)
      )
    }
    
    result.sort((a, b) => {
      switch (sortBy) {
        case 'newest': return new Date(b.createdAt) - new Date(a.createdAt)
        case 'oldest': return new Date(a.createdAt) - new Date(b.createdAt)
        case 'popular': return b.likes - a.likes
        case 'most-comments': return b.comments - a.comments
        default: return 0
      }
    })
    
    setFilteredPosts(result)
  }, [posts, activeCategory, sortBy, searchQuery])

  const handleLike = (postId) => {
    setPosts(prevPosts =>
      prevPosts.map(post =>
        post.id === postId
          ? { ...post, likes: post.likes + 1, isLiked: true }
          : post
      )
    )
  }

  const handleUpload = () => {
    alert('Feltöltés funkció aktív lenne itt!')
  }

  return (
    <div className="home-page">
      <Header 
        onSearch={setSearchQuery}
        onUploadClick={handleUpload}
      />
      
      <div className="main-content">
        {/* Bal sidebar - Kategóriák */}
        <aside className="sidebar-left">
          <div className="categories">
            <h3>Kategóriák</h3>
            <ul>
              <li 
                className={activeCategory === 'all' ? 'active' : ''}
                onClick={() => setActiveCategory('all')}
              >
                Összes
              </li>
              {mockCategories.map(category => (
                <li 
                  key={category.slug}
                  className={activeCategory === category.slug ? 'active' : ''}
                  onClick={() => setActiveCategory(category.slug)}
                >
                  {category.icon} {category.name}
                </li>
              ))}
            </ul>
          </div>
          
          <div className="layout-toggle">
            <button 
              className={layoutMode === 'grid' ? 'active' : ''}
              onClick={() => setLayoutMode('grid')}
              title="Rács nézet"
            >
              ⏹️
            </button>
            <button 
              className={layoutMode === 'masonry' ? 'active' : ''}
              onClick={() => setLayoutMode('masonry')}
              title="Masonry nézet"
            >
              🧱
            </button>
          </div>
        </aside>
        
        {/* Fő tartalom */}
        <main className="content">
          <FilterBar
            sortBy={sortBy}
            onSortChange={setSortBy}
            postCount={filteredPosts.length}
            layoutMode={layoutMode}
            onLayoutToggle={() => setLayoutMode(layoutMode === 'grid' ? 'masonry' : 'grid')}
          />
          
          {isLoading ? (
            <div className="loading">
              <div className="spinner"></div>
              <p>Betöltés...</p>
            </div>
          ) : filteredPosts.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">🎨</div>
              <h3>Nincs megjeleníthető tartalom</h3>
              <p>
                {searchQuery 
                  ? `Nincs találat a(z) "${searchQuery}" keresésre` 
                  : 'Próbáld meg más kategóriát választani!'}
              </p>
            </div>
          ) : (
            <div className={`posts-container ${layoutMode}`}>
              {filteredPosts.map(post => (
                <PostCard 
                  key={post.id}
                  post={post}
                  onLike={handleLike}
                />
              ))}
            </div>
          )}
        </main>
        
        {/* Jobb sidebar */}
        <aside className="sidebar-right">
          <div className="stats-card">
            <h4>Statisztikák</h4>
            <div className="stats">
              <div className="stat">
                <span className="number">{posts.length}</span>
                <span className="label">Alkotás</span>
              </div>
              <div className="stat">
                <span className="number">
                  {posts.reduce((sum, post) => sum + post.likes, 0)}
                </span>
                <span className="label">Kedvelés</span>
              </div>
              <div className="stat">
                <span className="number">
                  {new Set(posts.map(p => p.author)).size}
                </span>
                <span className="label">Művész</span>
              </div>
            </div>
          </div>
          
          <div className="trending">
            <h4>Trendező most</h4>
            {posts
              .sort((a, b) => b.likes - a.likes)
              .slice(0, 3)
              .map(post => (
                <div key={post.id} className="trending-item">
                  <img src={post.image} alt={post.title} />
                  <div className="trending-info">
                    <p className="trending-title">{post.title}</p>
                    <p className="trending-author">{post.author}</p>
                  </div>
                </div>
              ))}
          </div>
          
          <div className="call-to-action">
            <h4>Csatlakozz hozzánk!</h4>
            <p>Oszd meg alkotásaidat több ezer kreatívval</p>
            <button className="cta-button" onClick={handleUpload}>
              Kezdjük!
            </button>
          </div>
        </aside>
      </div>
    </div>
  )
}

export default HomePage