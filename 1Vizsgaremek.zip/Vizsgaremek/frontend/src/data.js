export const mockCategories = [
  { slug: 'all', name: 'Összes' },
  { slug: 'digital', name: 'Digitális festmény' },
  { slug: 'photography', name: 'Fényképezés' },
  { slug: 'vector', name: 'Vektorgrafika' },
  { slug: 'illustration', name: 'Illusztráció' },
  { slug: '3d', name: '3D művészet' },
  { slug: 'animation', name: 'Animáció' }
]

export const mockPosts = [
  {
    id: 1,
    title: 'Aurora Borealis',
    description: 'Digitális festmény az északi fényről, mélységet és csodálatot árasztva',
    image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&auto=format&fit=crop',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=artist1',
    author: 'AnnaDesign',
    category: 'Digitális festmény',
    tags: ['aurora', 'fény', 'festmény', 'fantasy'],
    likes: 245,
    comments: 32,
    isLiked: false,
    createdAt: '2024-01-15'
  },
  // ... további posztok
]