import HomePage from './pages/HomePage.jsx'

function App() {
  return <HomePage />
}

export default App